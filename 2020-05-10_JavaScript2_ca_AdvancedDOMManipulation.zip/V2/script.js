//Advanced DOM Manipulation
var element = document.getElementById("title");
var heading = document.createElement("h1");
var node = document.createTextNode("JavaScript CA: Advanced DOM Manipulation");
    heading.appendChild(node);
    element.appendChild(heading);
    title.style.fontSize = "20px";
    console.log ('Page title added');

//Create 9 of these cards. Use a for loop to create it.
var cards = ["1", "2", "3", "4", "5", "6", "7", "8", "9"];
var text = "";
var i;

//When it says it is number 1, that should increment by the number that it is in the loop.
for (i = 0; i < cards.length; i++) { //card content
    text += '<div class="card" id="' + cards[i] +'">'
            + '<h2>' + 'This is a test card for Noroff, it is number ' + cards[i] + '</h2>'
            + '<h3>' + 'By Michael' + '</h3>'
            + '<p>' + '43 minutes ago' + '</p>'
            + '<button>' + 'View on site' + '</button>'
            + '</div>'
}
//Every odd card should have a background color of #52ce90.
//The color of the text should change to white. It should look like the card below
$(document).ready(function(){
    $(".card:nth-child(odd)").addClass('odd'); // add odd class
    $(".card:nth-child(odd)").css("background-color", "#52CE90"); // green background: odd
    $(".card:nth-child(odd)").css("color", "#FFFFFF"); // white text: odd
    $(".card:nth-child(even)").addClass('even');// add even class
    console.log ('Colors changed for odd')
});

document.getElementById("cardContainer").innerHTML = text;

//Add the number of the loop to a data attribute.
document.getElementById("1").setAttribute("data-number", '1');
document.getElementById("2").setAttribute("data-number", '2');
document.getElementById("3").setAttribute("data-number", '3');
document.getElementById("4").setAttribute("data-number", '4');
document.getElementById("5").setAttribute("data-number", '5');
document.getElementById("6").setAttribute("data-number", '6');
document.getElementById("7").setAttribute("data-number", '7');
document.getElementById("8").setAttribute("data-number", '8');
document.getElementById("9").setAttribute("data-number", '9');


