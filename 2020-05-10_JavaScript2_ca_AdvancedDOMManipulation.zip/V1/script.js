const cards = document.querySelector("#cardContainer");

for (i = 0; i < 9; i++) {
    cards.innerHTML += `<div id="card" data-loop=" ${ i + 1 }">
        <div class="card__topText">This is a test Card for Noroff it is number ${ i + 1 }</div>
        <hr/>
        <div class="card__byText">By Name</div>
        <div class="card__whenText"> ${ i % 2 === 0 ? "an hour ago" : "43 minutes ago" }</div>
        <div class="card__button"><a href="#">View on site</a></div>
    </div>`;
}