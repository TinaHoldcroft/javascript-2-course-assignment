// AJAX and Typescript
// 6. Write code that displays all types of variables in typescript.

class typesOfVaribles {
	string: string = "Varible";
    number: number = 1;
    boolean: boolean = true;
    array: number[] = [1, 2, 3];
    tuple: [string, number];
    any: any = 4;
    void: void = undefined;
    undefined: undefined = undefined;
    null: null = null;
}