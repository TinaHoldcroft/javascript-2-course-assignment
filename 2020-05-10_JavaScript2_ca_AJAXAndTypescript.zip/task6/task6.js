// AJAX and Typescript
// 6. Write code that displays all types of variables in typescript.
var typesOfVaribles = /** @class */ (function () {
    function typesOfVaribles() {
        this.string = "Varible";
        this.number = 1;
        this.boolean = true;
        this.array = [1, 2, 3];
        this.any = 4;
        this.void = undefined;
        this.undefined = undefined;
        this.null = null;
    }
    return typesOfVaribles;
}());
