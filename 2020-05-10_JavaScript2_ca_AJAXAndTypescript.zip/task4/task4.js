// AJAX and Typescript
// 4. Connect to the API above using a promise. Create a new script file for this example.

fetch('https://www.amiiboapi.com/api/amiibo/?name=mario') // API

    .then(promise => {
        return promise.json(); // promise to get content
    })
    .then(content => {
        console.log(content.amiibo); // log content to console
    })
    .catch(error => {
        console.log(error) // log error to console
    })