// AJAX and Typescript
// 2. Connect to the API above using vanilla JavaScript. Create a new script file for this example. 
// 3. Console log your output.

getAmiiboContent("https://www.amiiboapi.com/api/amiibo/?name=mario", // API
    function(content) {
        console.log(content.amiibo); // console log list of content
});

function getAmiiboContent(url, callback) { // function to retrieve content
    var amiiboList = new XMLHttpRequest();
    amiiboList.onreadystatechange = function() {
        if (amiiboList.readyState !== 4) {
            return;
        }   
        if (amiiboList.status >= 200 && amiiboList.status < 300) {
            var content = JSON.parse(amiiboList.responseText);
            callback(content);
        }
        else {
            console.log ('error fetching content'); // error message if connect to API fails
        }
    };
    // Open the request
    amiiboList.open("GET", url);
    amiiboList.send();
}