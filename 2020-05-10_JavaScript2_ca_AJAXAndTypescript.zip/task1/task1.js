// AJAX and Typescript
// 1. Connect to the following API using JQuery. Create a new script file for this example.

$.ajax({
    url: "https://www.amiiboapi.com/api/amiibo/?name=mario", //API
    success: function(content) {
        console.log(content.amiibo); // log results to console
    },
    error: function(){
        alert('error!'); // error pop up
    }
})