// AJAX and Typescript
// 5. Create a typescript class, it should have a constructor that takes in a parameter. You should 
// pass your favourite fruit into the constructor and use a method to console log the name of the 
// fruit out.

class Fruit {
    fruitType: string;
    constructor(message: string) {
    this.fruitType = message;
    }
    type() {
        console.log ("My favorite type of fruit is " + this.fruitType);
        return this.fruitType
    }
}

let fruitFavorite = new Fruit("Oranges");
document.querySelector("#fruit").innerHTML = "My favorite type of fruit is " + fruitFavorite.type();