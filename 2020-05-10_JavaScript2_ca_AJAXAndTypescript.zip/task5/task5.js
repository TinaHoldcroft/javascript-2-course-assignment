// AJAX and Typescript
// 5. Create a typescript class, it should have a constructor that takes in a parameter. You should 
// pass your favourite fruit into the constructor and use a method to console log the name of the 
// fruit out.
var Fruit = /** @class */ (function () {
    function Fruit(message) {
        this.fruitType = message;
    }
    Fruit.prototype.type = function () {
        console.log("My favorite type of fruit is " + this.fruitType);
        return this.fruitType;
    };
    return Fruit;
}());
var fruitFavorite = new Fruit("Oranges");
document.querySelector("#fruit").innerHTML = "My favorite type of fruit is " + fruitFavorite.type();
