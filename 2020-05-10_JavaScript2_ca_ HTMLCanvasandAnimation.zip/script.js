//HTML Canvas Text
//Add text to a canvas that displays today's date.The text should be Verdana. It should have a stroke. It should be #52ce90 in color

var txtCanvas = document.getElementById("txtCanvas");

createTxt = txtCanvas.getContext("2d"); // create text canvas
createTxt.font = "30px Verdana"; // font: Verdana
createTxt.strokeStyle = "#52CE90"; // green text
createTxt.strokeText(new Date(), 1, 100); // display todays date in stroke style, placement    

//HTML Canvas Animation
//Take the example above and animate the text. It should slide in from left to right 
//(the animation should mimic the example created on day 3 for module 2).

var aniCanvas = document.getElementById("aniCanvas");
var path = 0;

createAni = aniCanvas.getContext("2d"); // create text canvas
createAni.strokeStyle = "#52CE90"; // green text
createAni.font = "30px Verdana"; // font: Verdana
createAni.fillStyle = "white"; //background

setInterval(function(){
    path++;
    createAni.fillRect(0, 0, aniCanvas.width, aniCanvas.height);
    createAni.strokeText(new Date(), path, 100);
},20); // speed